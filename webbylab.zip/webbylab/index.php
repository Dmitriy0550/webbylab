<?php
ini_set('display_errors', "1");
require_once "helper.php";
$config = include 'config.php';

$db = new mysqli($config['host'], $config['username'], $config['pass'], $config['db']);

$sort = get('sort');
$movie_id = get('movie_id');
//echo '<pre>';
//var_dump($_SERVER);
if ($movie_id) {
    movie_detail($movie_id);
} else {
    movies_list($sort);
}

function movies_list($sort = 'desc')
{
    global $db, $config;

    $limit = get('limit') ?: 25;
    $offset = get('offset') ?: 0;

    $star_flag = get('star_flag');
    $search = get('search');

    $query = "SELECT * FROM movies ";

    if ($search) {
        if ($star_flag) {
            $query .= " WHERE actors LIKE '%$search%' ";
        } else {
            $query .= " WHERE title LIKE '%$search%' ";
        }
    }

    $query .= " ORDER BY title $sort LIMIT $offset, $limit";

    if (!($result = $db->query($query))) {
        die($db->error);
    }

    $movies = $result->fetch_all(MYSQLI_ASSOC);

//    var_dump($movies);

    include 'views/movies_list.php';
}

function movie_detail($movie_id)
{
    global $db, $config;

    $query = "SELECT * FROM movies WHERE id = '$movie_id'";

    $movie = $db->query($query);
    $movie = $movie->fetch_assoc();

    include 'views/movie_detail.php';
}