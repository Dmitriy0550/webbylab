<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Add new movie</title>
    <script src="js/bootstrap.bundle.js"></script>
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/main.css">
</head>
<body>
<div class="container">
    <form action="" method="post" enctype="multipart/form-data">
        <div class="form-group">
            <label for="title">Movie title</label>
            <input type="text" class="form-control" id="title" name="title" placeholder="Enter movie title">
        </div>
        <div class="form-group">
            <label for="release_year">Release year</label>
            <input type="text" class="form-control" id="release_year" name="release_year" placeholder="Year of movie release">
        </div>
        <div class="form-group">
            <label for="format">Movie format</label>
            <input type="text" class="form-control" id="format" name="format" placeholder="Movie format (VHS, DVD etc)">
        </div>
        <div class="form-group">
            <label for="actors">Actors</label>
            <textarea class="form-control" name="actors" id=actors"" cols="30" rows="10"></textarea>
        </div>
        <div class="custom-file">
            <input type="file" name="file" class="file-input" id="customFile">
            <label class="custom-file-label" for="customFile">Choose file to load</label>
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
</div>
</body>
</html>