<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <script src="js/bootstrap.bundle.js"></script>
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/main.css">
    <title>Movies list</title>
</head>
<body>
<script>
    function send_search() {
        if (window.event.keyCode == '13') {
            document.search.submit();
            document.search.method = 'get';
        }
    }
</script>
<div class="container">
    <div class="btn-group btn-group-toggle" data-toggle="buttons">
        <a class="btn btn-secondary <?php echo $sort == 'desc' ? 'active' : ''; ?>"
           href="<?php echo url(); ?>?<?php echo query('sort', 'desc') ?>">DESC</a>
        <a class="btn btn-secondary <?php echo $sort == 'asc' ? 'active' : ''; ?>"
           href="<?php echo url(); ?>?<?php echo query('sort', 'asc') ?>">ASC</a>
    </div>
    <form action="" method="get" id="search">
        <div class="btn-group">
            <div class="input-group">
                <input type="text" class="form-control" name="search" aria-label="Search" onkeydown="send_search()">
                <div class="input-group-append">
                    <label class="input-group-text" id="inputGroup-sizing-default">
                    <input name="star_flag" type="checkbox" aria-label="Checkbox for following text input" class="input">
                        &nbsp; Search by star
                    </label>
                </div>
                <div class="a">
                    <a href="http://localhost:8888/webbylab/add.php" style="margin:10px;"  >Add new movies</a>
                </div>
                <div class="input-group-append">
                </div>
            </div>
        </div>
    </form>

</div>

<div class="container">
    <?php foreach ($movies as $movie) { ?>
        <div class="card" style="width: 18rem;">
            <div class="card-body">
                <h5 class="card-title"><?php echo $movie['title']; ?></h5>
                <p class="card-text"><?php echo $movie['release_year']; ?></p>
                <p class="card-text"><?php echo $movie['format']; ?></p>
                <p class="card-text"><?php echo $movie['actors']; ?></p>
                <a href="<?php echo url(); ?>?<?php echo query('movie_id', $movie['id']); ?>" class="btn btn-primary">Details</a>
            </div>
        </div>
    <?php } ?>
</div>
</body>
</html>