<?php

function get($key)
{
    return isset($_GET[$key]) ? $_GET[$key] : false;
}

function url()
{
    return 'http://'.$_SERVER['HTTP_HOST'] . $_SERVER['SCRIPT_NAME'];
}

function query($key, $value)
{
     parse_str($_SERVER['QUERY_STRING'], $query);
     $query[$key] = $value;
     return http_build_query($query);
}