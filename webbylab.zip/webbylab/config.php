<?php

return array(
    'host' => 'localhost',
    'username' => 'root',
    'pass' => 'root',
    'db' => 'webbylab'
);