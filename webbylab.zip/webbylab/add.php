<?php
//ini_set('display_errors', '1');
require_once "helper.php";
$config = include 'config.php';

$data = $_POST;
$file = $_FILES['file'];

if ($file) {

    $db = new mysqli($config['host'], $config['username'], $config['pass'], $config['db']);

    $content = trim(file_get_contents($file['tmp_name']));
    $content = preg_split("#\n\s*\n#Uis", $content);

    $movies = array();
    foreach ($content as $item) {
        $movie = explode("\n", $item);
        $movies [] = array(
            'title' => trim(array_pop(explode(':', $movie[0]))),
            'release_year' => trim(array_pop(explode(':', $movie[1]))),
            'format' => trim(array_pop(explode(':', $movie[2]))),
            'actors' => trim(array_pop(explode(':', $movie[3])))
        );
    }

    $movies_count = count($movies);
    $query = "INSERT INTO movies (title, release_year, format, actors) VALUES ";
    foreach ($movies as $index => $movie) {
        $query .= "('{$movie['title']}', '{$movie['release_year']}', '{$movie['format']}', '{$movie['actors']}')";
        if ($index < $movies_count-1) $query .= ",";
    }

//    echo '<pre>';
//    var_dump($query);

    $result = $db->query($query);
    if (!$result) {
        echo $db->error;
    } else {
        echo "Movies from file has been added!";
    }

} else
    if ($data) {

        $db = new mysqli($config['host'], $config['username'], $config['pass'], $config['db']);

        $data = array_map(function ($item) {
            return filter_var($item, FILTER_SANITIZE_STRING);
        }, $data);

        $query = "INSERT INTO movies (title, release_year, format, actors) VALUE ('{$data['title']}', '{$data['release_year']}', '{$data['format']}', '{$data['actors']}')";

        $result = $db->query($query);

        if (!$result) {
            echo $db->error;
        } else {
            echo "Movie {$data['title']} has been added!";
        }

    } else {
        include 'views/add_form.php';
    }

